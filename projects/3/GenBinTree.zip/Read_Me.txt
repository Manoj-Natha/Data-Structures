
1. Open the .java file in JGrasp.
2. Compile and run the file in JGrasp.
3. You can change the values of nodes for add, swap, delete, find, rotateLeft and rotateRight in the main function. 